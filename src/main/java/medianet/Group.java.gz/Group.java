package medianet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Group {
    private  String gid ;
    private  List<User> users = new ArrayList<User>() ;
    private List<Expense> expenses = new ArrayList<Expense>() ;

    private  String admin ;

    Group(String gid,String admin){
        this.gid = gid ;
        this.admin = admin ;

    }



    public  void addUser(User user){
        users.add(user);
    }

    public void addExpense(Expense expense){
        expenses.add(expense);
    }


    public Map<String,Double> expenseReport(){
        Double totalSum=0.0 ;
        Map<String,Double> map = new HashMap<String,Double>() ;
        Map<String,Double> dmap = new HashMap<String, Double>() ;
        for(Expense e: expenses){
            totalSum +=e.getTotalAmount() ;
            for(PairU p: e.getOwners()){
                if(!map.containsKey(p.a.userId)){
                    map.put(p.a.userId,p.amount) ;
                }else{
                    Double amount  = map.get(p.a.userId) ;
                    map.put(p.a.userId,amount+p.amount) ;
                }

            }

            for(PairU p : e.getPartitions()){

                if(!dmap.containsKey(p.a.userId)){
                    dmap.put(p.a.userId,p.amount) ;
                }else{
                    Double amount  = dmap.get(p.a.userId) ;
                    dmap.put(p.a.userId,amount+p.amount) ;
                }

            }

        }


        Map<String,Double> ans = new HashMap<String,Double>() ;

        for(String key:dmap.keySet()){

            Double paid = (!map.containsKey(key)?0.0:map.get(key)) ;
            Double own = dmap.get(key) ;
            ans.put(key,paid-own) ;


        }


        return ans ;



    }


}
