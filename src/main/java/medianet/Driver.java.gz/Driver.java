package medianet;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Driver {


    public static void main(String[] args) {

        User A = new User("A") ;
        User B = new User("B") ;
        User C = new User("C") ;

        Group group = new Group("gid","A") ;
        group.addUser(A); group.addUser(B);group.addUser(C);

        List<User> users = new ArrayList<User>() ;

        Expense e = new Expense("e1","gid",users,100.0) ;

        e.addOwners(new PairU(A,100.0));

        e.addPartition(new PairU(A,33.33));
        e.addPartition(new PairU(B,33.33));
        e.addPartition(new PairU(C,33.33));
        Expense e1 = new Expense("e2","gid",users,100.0) ;

        e1.addOwners(new PairU(B,100.0));

        e1.addPartition(new PairU(A,33.33));
        e1.addPartition(new PairU(B,33.33));
        e1.addPartition(new PairU(C,33.33));

        group.addExpense(e); group.addExpense(e1);


        Map<String,Double> ans = group.expenseReport() ;










    }
}
