package medianet;

public class User {

    String userId ;

    User(String userId){
        this.userId =userId ;
    }
}
