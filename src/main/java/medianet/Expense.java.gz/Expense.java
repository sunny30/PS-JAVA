package medianet;

import java.util.ArrayList;
import java.util.List;

class PairU{

    User a ;
    Double amount ;

    PairU(User a, Double amount){
        this.a = a ;
        this.amount = amount ;
    }


}
public class Expense {

    private String eid ;
    private  String gid ;
    List<User> users ;



    private Double totalAmount ;
    private List<PairU> partitions = new ArrayList<PairU>() ;
    private  List<PairU> owners = new ArrayList<PairU>() ;



    Expense(String eid,String gid,List<User> users,Double totalAmount){

        this.eid = eid ;this.gid = gid ;
        this.users = users ;
        this.totalAmount = totalAmount ;


    }


    public void addPartition(PairU p){
        partitions.add(p);

    }

    public void addOwners(PairU p) {
        owners.add(p);
    }

    public String getEid() {
        return eid;
    }

    public void setEid(String eid) {
        this.eid = eid;
    }

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(Double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public List<PairU> getPartitions() {
        return partitions;
    }

    public void setPartitions(List<PairU> partitions) {
        this.partitions = partitions;
    }

    public List<PairU> getOwners() {
        return owners;
    }

    public void setOwners(List<PairU> owners) {
        this.owners = owners;
    }




}
