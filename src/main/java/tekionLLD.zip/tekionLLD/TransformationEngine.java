package tekionLLD;

public class TransformationEngine {




    public void execute(String transformationString,String transformationName,String entityName,String dealerName){
        System.out.println("applying transformation "+transformationName+" "+entityName+" "+dealerName);
    }




}
